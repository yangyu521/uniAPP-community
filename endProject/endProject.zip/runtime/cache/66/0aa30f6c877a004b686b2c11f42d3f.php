<?php
//000000000000
 exit();?>
think_serialize:a:7:{s:8:"username";s:11:"15245657899";s:5:"phone";s:11:"15245657899";s:8:"password";s:60:"$2y$10$EawjRrrCAiynyKfco0yafeMtNsDwRGOdBufWzikxPdhTwfcYg8NC.";s:11:"create_time";s:19:"2021-02-09 15:23:12";s:11:"update_time";s:19:"2021-02-09 15:23:12";s:2:"id";s:3:"406";s:5:"token";s:40:"157ef761110c693b4e40a661ac62a59bc04b4e5b";}