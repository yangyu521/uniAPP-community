<?php
//000000000000
 exit();?>
think_serialize:a:7:{s:8:"username";s:11:"15503324664";s:5:"phone";s:11:"15503324664";s:11:"create_time";s:19:"2021-02-09 15:57:25";s:11:"update_time";s:19:"2021-02-09 15:57:25";s:2:"id";s:3:"407";s:9:"logintype";s:5:"phone";s:5:"token";s:40:"3b940be360d590d5d0e44578b456464d09ce0ac1";}