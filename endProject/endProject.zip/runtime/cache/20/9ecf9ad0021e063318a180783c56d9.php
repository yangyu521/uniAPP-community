<?php
//000000000000
 exit();?>
think_serialize:a:6:{s:8:"username";s:11:"15903324664";s:5:"phone";s:11:"15903324664";s:11:"create_time";s:19:"2021-02-05 16:42:05";s:11:"update_time";s:19:"2021-02-05 16:42:05";s:2:"id";s:3:"400";s:5:"token";s:40:"98e8bd9ec8c92e8208579d55b11265edcbfcb43d";}