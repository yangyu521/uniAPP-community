<?php
//000000000000
 exit();?>
think_serialize:a:9:{s:2:"id";i:404;s:8:"username";s:11:"13473269000";s:7:"userpic";N;s:8:"password";s:60:"$2y$10$4.e0rD2bW.zSRxRL1LQOQO12o/HtFyEKWtAIXfGQKqk0b/v97qH/q";s:5:"phone";s:11:"13473269000";s:5:"email";N;s:6:"status";i:1;s:11:"create_time";s:19:"2021-02-06 15:49:23";s:5:"token";s:40:"1a0fbd6292049dd54a0af2a0a28e8157ab16d690";}