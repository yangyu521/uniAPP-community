<?php
//000000000000
 exit();?>
think_serialize:a:7:{s:8:"username";s:11:"17717153849";s:5:"phone";s:11:"17717153849";s:8:"password";s:60:"$2y$10$GNEGyk9x/qcWqmyEvxtp.ODHmWsqSnoqNeDLh0LtWoCzwW/tdVEKu";s:11:"create_time";s:19:"2021-02-05 16:55:34";s:11:"update_time";s:19:"2021-02-05 16:55:34";s:2:"id";s:3:"403";s:5:"token";s:40:"a1a208df987cdf012d76a34ca409c16ca05c629f";}