<?php
//000000000000
 exit();?>
think_serialize:a:7:{s:8:"username";s:11:"15903324665";s:5:"phone";s:11:"15903324665";s:8:"password";s:60:"$2y$10$8uWicYbhGPM4dvmO.SnMQeDK07OmAeiB8Zf8uZ4pqUJhpi282pibu";s:11:"create_time";s:19:"2021-02-07 16:17:20";s:11:"update_time";s:19:"2021-02-07 16:17:20";s:2:"id";s:3:"405";s:5:"token";s:40:"fc02aa1384655ccd6ae3840d40d27573daa807a4";}