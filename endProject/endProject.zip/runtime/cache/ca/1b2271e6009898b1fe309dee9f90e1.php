<?php
//000000000000
 exit();?>
think_serialize:a:7:{s:8:"username";s:11:"15903324774";s:5:"phone";s:11:"15903324774";s:11:"create_time";s:19:"2021-02-09 16:09:14";s:11:"update_time";s:19:"2021-02-09 16:09:14";s:2:"id";s:3:"409";s:9:"logintype";s:5:"phone";s:5:"token";s:40:"84f03123110d414ab1fcab31e1647a708b978791";}