<?php
//000000000000
 exit();?>
think_serialize:a:7:{s:8:"username";s:11:"13473269000";s:5:"phone";s:11:"13473269000";s:8:"password";s:60:"$2y$10$4.e0rD2bW.zSRxRL1LQOQO12o/HtFyEKWtAIXfGQKqk0b/v97qH/q";s:11:"create_time";s:19:"2021-02-06 15:49:23";s:11:"update_time";s:19:"2021-02-06 15:49:23";s:2:"id";s:3:"404";s:5:"token";s:40:"95603efae18156e288ca1639e29755ba2f7f7e49";}