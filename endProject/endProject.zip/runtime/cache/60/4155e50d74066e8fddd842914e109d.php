<?php
//000000000000
 exit();?>
think_serialize:a:6:{s:8:"username";s:11:"13473269306";s:5:"phone";s:11:"13473269306";s:11:"create_time";s:19:"2021-02-05 16:49:34";s:11:"update_time";s:19:"2021-02-05 16:49:34";s:2:"id";s:3:"401";s:5:"token";s:40:"7ac5bbcb1d6c0ce2bb7295a042112c052791eff5";}