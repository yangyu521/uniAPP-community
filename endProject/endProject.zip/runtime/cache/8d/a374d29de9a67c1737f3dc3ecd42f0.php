<?php
//000000000000
 exit();?>
think_serialize:a:7:{s:8:"username";s:11:"14523567896";s:5:"phone";s:11:"14523567896";s:11:"create_time";s:19:"2021-02-09 16:02:36";s:11:"update_time";s:19:"2021-02-09 16:02:36";s:2:"id";s:3:"408";s:9:"logintype";s:5:"phone";s:5:"token";s:40:"c0f2759c28a14d3b866fbf37d1d175e6eab8c587";}